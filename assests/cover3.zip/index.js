 let songIndex=0;
 let audioElement=new Audio('1.mp3');
 let masterPlay=document.getElementById("masterPlay");
 let myProgressBar=document.getElementById("myProgressBar");
 let gif=document.getElementById('gif');
 let songItems=Array.from(document.getElementsByClassName('songItem'));
 let masterSongName=document.getElementById("masterSongName");
//  let songItemPlay=document.getElementsByClassName("songItemPlay");
 
let song = [

    {songName:"Arjan Vailly" ,filePath:"1.mp3" , coverPath :"cover1.jpg"},
    {songName:"Chaleya" ,filePath:"2.mp3" , coverPath :"cover2.jpg"},
    {songName:"Pal" ,filePath:"4.mp3" , coverPath :"cover3.jpg"},
    {songName:"Agar Tum Sath Ho" ,filePath:"3.mp3" , coverPath :"cover4.jpg"},
    {songName:"Humdard" ,filePath:"5.mp3" , coverPath :"cover5.jpg"},
    {songName:"Salamat" ,filePath:"6.mp3" , coverPath :"cover6.jpg"},
    {songName:"Laree Chhoote" ,filePath:"7.mp3" , coverPath :"cover7.jpg"},
    {songName:"Kachcha Ghada" ,filePath:"8.mp3" , coverPath :"cover8.webp"},

]

songItems.forEach((element,i)=>{
    element.getElementsByTagName("img")[0].src=song[i].coverPath;
    element.getElementsByClassName("songName")[0].innerText=song[i].songName;
})

const makeAllPlays=()=>{
    Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
        element.classList.remove("fa-circle-pause");
        element.classList.add("fa-circle-play");

    })

}
Array.from(document.getElementsByClassName('songItemPlay')).forEach((element)=>{
    element.addEventListener('click',(e)=>{
        makeAllPlays();
        songIndex=parseInt(e.target.id);
        e.target.classList.remove("fa-circle-play");
        e.target.classList.add("fa-circle-pause");
        gif.style.opacity=1;
        audioElement.src=`${songIndex+1}.mp3`;
        masterSongName.innerText=song[songIndex].songName;
        audioElement.currentTime=0;
        audioElement.play();
        masterPlay.classList.remove("fa-circle-play");
        masterPlay.classList.add("fa-circle-pause");
    })

})

// audioElement.play();
masterPlay.addEventListener('click',()=>{
    if(audioElement.paused  ||  audioElement.currentTime<=0){
        audioElement.play();
        masterPlay.classList.remove("fa-circle-play");
        masterPlay.classList.add("fa-circle-pause");
       
        gif.style.opacity=1;
       

    }
    else{
        audioElement.pause();
        masterPlay.classList.remove('fa-circle-pause');
        masterPlay.classList.add('fa-circle-play');
        gif.style.opacity=0;
        
    }
})
audioElement.addEventListener('timeupdate',()=>{

    console.log('timeupdate');
    let progress = parseInt((audioElement.currentTime/audioElement.duration)*100);
    myProgressBar.value=progress;
})

myProgressBar.addEventListener('change',()=>{
    audioElement.currentTime=myProgressBar.value*audioElement.duration/100;
    
})

document.getElementById('next').addEventListener('click',()=>{

    if(songIndex>=6){
        songIndex=-1;
    }
    else{
   songIndex+=1;
    

    audioElement.src=`${songIndex+1}.mp3`;
    masterSongName.innerText=song[songIndex].songName;
    audioElement.currentTime=0;
    audioElement.play();
    masterPlay.classList.remove("fa-circle-play");
    masterPlay.classList.add("fa-circle-pause");  
    } 
})

document.getElementById('previous').addEventListener('click',()=>{

    if(songIndex<=0){
        songIndex=0;
    }
    else{
   songIndex-=1;
    
    audioElement.src=`${songIndex+1}.mp3`;
     masterSongName.innerText=song[songIndex].songName;
    audioElement.currentTime=0;
    audioElement.play();
    masterPlay.classList.remove("fa-circle-play");
    masterPlay.classList.add("fa-circle-pause");
    }
 
})